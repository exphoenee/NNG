const trt = { 1: "st", 2: "nd", 3: "rd", default: "th" };
